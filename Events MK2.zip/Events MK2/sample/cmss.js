var express = require("express");
var app     = express();
var path    = require("path");
var mysql = require('mysql');
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "cms"
});
app.get('/',function(req,res){
  res.sendFile(path.join(__dirname+'/patient/app.html'));
});
app.post('/submit',function(req,res){

  var PatientName=req.body.PatientName;
  var Age=req.body.Age;
  var Gender=req.body.Gender;
  var Address=req.body.Address;
  var Symptoms=req.body.Symptoms;
  var datee=req.body.datee;
  var timee=req.body.timee;
  res.write('You sent the PatientName "' + req.body.PatientName+'".\n');
  res.write('You sent the Age "' + req.body.Age+'".\n');
  res.write('You sent the Gender "' + req.body.Gender+'".\n');
  res.write('You sent the Address "' + req.body.Address+'".\n');
  res.write('You sent the Symptoms "' + req.body.Symptoms+'".\n');
  res.write('You sent the datee "' + req.body.datee+'".\n');
  res.write('You sent the timee "' + req.body.timee+'".\n');
  

  con.connect(function(err) {
  if (err) throw err;
  var sql = "INSERT INTO patientrecord (PatientName, Age,Gender, Address, Symptoms, datee, timee) VALUES ('"+PatientName+"', '"+Age+"','"+Gender+"','"+Address+"','"+Symptoms+"','"+datee+"','"+timee+"')";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("1 record inserted");
     res.end();
  });
  });
})
app.listen(5500);
console.log("Running at Port 5500");
