const express = require('express');
const app = express();
// we create 'users' collection in newdb database
var url1 = "mongodb://localhost:27017/";
 
// create a client to mongodb
var MongoClient = require('mongodb').MongoClient;
const port = 3005;
// Define the static file path
var cookieParser = require('cookie-parser');
app.use(cookieParser());
app.use(express.urlencoded({
  extended: true
}))
app.use(express.static('images'));

app.get('/', function (req, res) {
  res.sendFile(`${__dirname}/user.html`);
})
app.get('/user.html', function (req, res) {
  res.sendFile(`${__dirname}/user.html`);
})

app.get('/reg.html', function (req, res) {
  res.sendFile(`${__dirname}/reg.html`);
})
app.get('/login.html', function (req, res) {
  res.sendFile(`${__dirname}/login.html`);
})
app.get('/getwork.html', function (req, res) {
  res.sendFile(`${__dirname}/getwork.html`);
})

app.get('/progress.html', function (req, res) {
  res.sendFile(`${__dirname}/progress.html`);
})
app.post('/reg', (req, res) => {
   
  var obj=req.body;
  console.log(obj);
  MongoClient.connect(url1, function(err, db) {
    if (err) throw err;
    var dbo = db.db("cms");
    
    dbo.collection("customers").insertOne(obj, function(err, res) {
      if (err) throw err;
      console.log("1 document inserted");
      
      db.close();
    });
    
  });
  res.send(`<script>window.location.href = 'login.html';</script>`);
 res.end();
})

app.post('/login',(req, res) => {
  var obj=req.body;
  var user;
  
  MongoClient.connect(url1, async function(err, db) {
    if (err) throw err;
    var dbo = db.db("cms");
    
    dbo.collection("customers").find(obj).toArray(async function (err, result) {
        if (err)
          throw err;
        user = result;

        db.close();
      });
    
  })


  console.log(user);
  res.send("<script>window.location.href = 'user.html';</script>");
  
 
  
 res.end();
})
app.listen(port, () => console.log('The server running on Port '+port));